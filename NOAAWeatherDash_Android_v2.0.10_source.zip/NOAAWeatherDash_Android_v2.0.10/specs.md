# NOAA Weather Dash Android — Technical Specifications

Current baseline: **v2.0.10**  
Source lineage: **v2.0.9 preserved and incrementally extended**  
Legacy support goal: **Android 6.0 / API 23+**

## 1. Build and platform baseline

- Application ID: `com.noaaweatherdash.android`
- Namespace: `com.noaaweatherdash`
- Current version: code `210`, name `2.0.10`
- `minSdk 23`
- `targetSdk 35`
- `compileSdk 35`
- Android Gradle Plugin: `8.6.1`
- Gradle wrapper target: `8.7`
- JDK: `17`
- Main Java activity: `com.noaaweatherdash.MainActivity`
- UI runtime: Android WebView loading `file:///android_asset/index.html`
- Leaflet 1.9.4 is bundled into APK assets.
- Android permission: `INTERNET`
- Cleartext HTTP disabled.
- Hardware acceleration enabled.

## 2. Existing architecture

### Native shell

`MainActivity` creates one `WebView`, enables JavaScript/DOM storage/database/image loading, and loads the packaged HTML asset. There is no native weather-data service layer in the current baseline.

### Web application

The HTML/JavaScript layer owns:

- Leaflet map state;
- OpenStreetMap base map;
- RainViewer metadata and tile selection;
- NOAA MRMS fallback overlay;
- Open-Meteo current/hourly requests;
- NWS comparison requests;
- ZIP/coordinate preferences;
- UI rendering.

### Radar

RainViewer must remain an **observed radar** source. The baseline already configures:

- `minNativeZoom: 2`
- `maxNativeZoom: 7`
- map/layer `maxZoom: 12`

Thus map zoom 8–12 must upscale native Z7 radar rather than request unsupported RainViewer tile zooms.

NOAA MRMS is a distinct observed-radar source and must not be mislabeled as RainViewer data.

## 3. v2.0.10 implemented forecast contract

### Primary Open-Meteo request

The implementation uses one Open-Meteo request for current, hourly, and ten daily forecast days.

Required current fields:

- `temperature_2m`
- `relative_humidity_2m`
- `wind_speed_10m`
- `wind_direction_10m`
- `weather_code`

Required hourly fields:

- `temperature_2m`
- `relative_humidity_2m`
- `wind_speed_10m`
- `precipitation_probability`
- `precipitation`
- `rain`
- `showers`
- `snowfall`
- `weather_code`

Required daily fields for ten-day cards:

- `weather_code`
- `temperature_2m_max`
- `temperature_2m_min`
- `relative_humidity_2m_mean`
- `precipitation_probability_max`
- `precipitation_sum`
- `rain_sum`
- `showers_sum`
- `snowfall_sum`
- `wind_speed_10m_max`
- `wind_gusts_10m_max`
- `wind_direction_10m_dominant`

Set:

- `forecast_days=10`
- `temperature_unit=fahrenheit`
- `wind_speed_unit=mph`
- `precipitation_unit=inch` if supported consistently by the chosen endpoint; otherwise convert once in normalization code.
- `timezone=auto`

### Future normalized data model

v2.0.10 still renders the Open-Meteo response directly to preserve the legacy architecture. Before enabling additional forecast providers, rendering should be moved to a provider-independent structure. Minimum conceptual structure:

```text
WeatherSnapshot
  provider
  location
  generatedAt
  current
  hourly[]
  daily[]
  alerts[]
```

Daily normalized fields:

```text
DailyForecast
  date
  conditionCode
  conditionText
  tempHighF
  tempLowF
  humidityMeanPct
  precipProbabilityPct
  precipTotalIn
  rainIn
  showersIn
  snowfallIn
  precipType
  windMaxMph
  windGustMaxMph
  windDirectionDeg
```

Missing provider fields must remain `null`/unavailable; do not fabricate zero values.

## 4. Provider strategy

### Default / no-key providers

**Open-Meteo**
- Best fit for the default global 10-day UI.
- No API key for free non-commercial use.
- Supports up to 16 forecast days and the daily aggregates required by the intended cards.
- Attribution is required and the free hosted API is non-commercial.

**NOAA/NWS**
- Keep as authoritative U.S. comparison source.
- Free/open government data with no API key.
- Forecast horizon is approximately seven days, so it cannot populate all ten daily cards.
- Use it as a comparison rather than force-fill days 8–10.

**Visual Crossing**
- Strong candidate for a second global comparison source because the Timeline API supplies up to 15 forecast days and rich daily metrics.
- Current documentation offers anonymous/no-key free access under fair-use controls, and account-based free usage remains available.
- Add as optional/experimental until quota behavior and attribution are validated in the app.

### Optional keyed providers

**Google Weather API**
- Excellent metric match: up to 10 daily forecast days, rich precipitation/humidity/wind/gust/apparent-temperature fields.
- Production requires an API key and billing-enabled Google Cloud project.
- The Weather SKU currently has a monthly free usage cap, but this is not a no-billing production service.
- Do not embed a shared production key in HTML or APK assets.

**OpenWeather One Call**
- Useful independent global comparison.
- 1,000 calls/day are included free in the One Call subscription, then pay-per-call.
- One Call 3.0 provides only eight daily forecast days, so it is not the cleanest ten-day source.

**WeatherAPI.com**
- Large free call allowance, but the free forecast horizon is only three days.
- Useful for current/short-range validation, not as the primary ten-day source.

**Weatherstack**
- Free plan is current-weather only and has a very small monthly quota.
- Forecast requires paid tiers.
- Not recommended for the default forecast path.

## 5. API-key handling

Never ship a reusable shared secret directly in:

- `index.html`;
- JavaScript assets;
- `BuildConfig` expecting it to remain secret;
- an APK resource.

APK contents can be extracted and browser/WebView requests expose keys to the client. For optional keyed sources, choose one of these patterns:

1. user supplies their own key in Settings and accepts that it is stored locally on their device; or
2. add a controlled server/proxy owned by the operator; or
3. add a native Android request layer with provider-specific key restrictions where the provider supports them.

The legacy app should continue working with no keyed provider configured.

## 6. UI requirements

- Daily section must be directly below Hourly.
- Maintain horizontal scrolling and touch-friendly cards.
- Do not replace Hourly with Daily; both remain visible.
- Provider comparison text must identify the provider by name.
- A missing metric should render as `--`, not `0`.
- Source/provider errors must not blank the whole dashboard when another source still works.
- Radar errors must remain independent of forecast errors.

## 7. Compatibility requirements

- Preserve ES syntax compatible with Android System WebView on supported API 23-era devices; avoid introducing new JavaScript syntax without testing legacy WebView behavior.
- Maintain XHR fallback for environments where `fetch` is unavailable or unreliable.
- Do not add heavy frameworks unless justified by a tested feature requirement.
- Keep map and forecast usable in portrait and landscape.

## 8. Verification status and gates for v2.0.10

Source-level verification completed in the development environment:

- v2.0.10 regression checks pass.
- Inline JavaScript parses successfully under Node.js syntax checking.
- A runtime Daily renderer test generates exactly ten cards and verifies the planned metric labels, inch precipitation, and wind-direction conversion.
- RainViewer `maxNativeZoom:7` remains present.
- Gradle execution could not complete in the sandbox because the wrapper could not resolve `services.gradle.org`; this is an environment network/DNS limitation, not a Gradle compiler result.

Remaining release gates:

- Gradle debug build succeeds with JDK 17 / wrapper 8.7.
- APK installs and starts on at least one legacy Android device/API-level representative.
- RainViewer requests never exceed native Z7.
- Ten Daily cards render when Open-Meteo returns ten days.
- Hourly still renders 24 cards around the current time.
- Daily precipitation conversion is correct and not double-converted.
- Open-Meteo failure does not break radar.
- NWS failure does not break Open-Meteo.
- Saved ZIP/lat/lon settings survive restart.
- Visible version says v2.0.10 everywhere.
- Verify the produced APK on at least one API-23-era or representative legacy Android device.

## 9. Current provider references

Research date: 2026-11-18.

- Open-Meteo docs: https://open-meteo.com/en/docs
- Open-Meteo terms: https://open-meteo.com/en/terms
- NWS API: https://www.weather.gov/documentation/services-web-api
- Visual Crossing Timeline API: https://www.visualcrossing.com/resources/documentation/weather-api/timeline-weather-api/
- WeatherAPI.com pricing: https://www.weatherapi.com/pricing
- OpenWeather pricing: https://openweathermap.org/price
- Google Weather API: https://developers.google.com/maps/documentation/weather/
- Google Weather pricing: https://developers.google.com/maps/billing-and-pricing/pricing
- Weatherstack FAQ: https://weatherstack.com/faq
