
const $=x=>document.getElementById(x);const S={lat:+localStorage.lat||42.9634,lon:+localStorage.lon||-85.6681,zip:localStorage.zip||'',placeLabel:localStorage.placeLabel||'',site:(localStorage.site||'KGRR').toUpperCase(),source:'rain',weather:new Set(['open','nws']),frames:[],frame:0,playing:false,timer:null,map:null,radarLayer:null,base:null};$('lat').value=S.lat;$('lon').value=S.lon;$('zip').value=S.zip;$('site').value=S.site;
function fmt(v){return v==null?'--':Math.round(v)}function wx(code){return ({0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',73:'Snow',75:'Heavy snow',80:'Showers',81:'Showers',82:'Heavy showers',95:'Thunderstorm',96:'Thunderstorm + hail',99:'Thunderstorm + hail'})[code]||'Conditions'}
function mapInit(){if(!window.L){$('radarTag').textContent='RADAR · map library unavailable';$('radarStatus').textContent='Map library failed to load';$('err').textContent='Map: Leaflet could not be loaded from the bundled app asset.';return false}S.map=L.map('map',{zoomControl:true,preferCanvas:false,minZoom:2,maxZoom:12}).setView([S.lat,S.lon],8);S.base=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:12,attribution:'© OpenStreetMap contributors'}).addTo(S.map);setTimeout(function(){S.map&&S.map.invalidateSize(true)},200);return true}

function loadRain(){
  $('radarStatus').textContent='loading RainViewer observed timeline…';
  httpJSON('https://api.rainviewer.com/public/weather-maps.json',function(j){
    var p=(j.radar&&j.radar.past)||[];
    if(!p.length) throw new Error('RainViewer returned no observed radar frames');
    S.rainFrames=p.map(function(x){return {t:x.time,path:x.path,kind:'past',source:'rain'}});
    if(S.source==='rain'){
      S.frames=S.rainFrames.slice();
      $('timeline').max=Math.max(0,S.frames.length-1);
      renderFrame(S.frames.length-1);
      $('radarStatus').textContent='RainViewer observed timeline ready';
    }
  },function(e){$('radarStatus').textContent='RainViewer timeline unavailable';$('err').textContent='Radar: '+e.message});
}

function loadNoaaTimeline(){
  $('radarStatus').textContent='loading NOAA MRMS 4-hour timeline…';
  var u='https://mapservices.weather.noaa.gov/eventdriven/rest/services/radar/radar_base_reflectivity_time/ImageServer?f=pjson&_='+Date.now();
  httpJSON(u,function(j){
    var ext=j.timeInfo&&j.timeInfo.timeExtent;
    if(!ext||ext.length<2) throw new Error('NOAA MRMS time extent unavailable');
    var start=Math.floor(ext[0]/60000)*60000,end=Math.floor(ext[1]/60000)*60000,step=5*60000,frames=[];
    for(var t=start;t<=end;t+=step) frames.push({t:Math.floor(t/1000),kind:'past',source:'noaa'});
    if(!frames.length) throw new Error('NOAA MRMS returned no frames');
    S.noaaFrames=frames;
    if(S.source==='noaa'){S.frames=frames;$('timeline').max=Math.max(0,frames.length-1);renderFrame(frames.length-1);$('radarStatus').textContent='NOAA MRMS timeline ready';}
  },function(e){$('radarStatus').textContent='NOAA MRMS timeline unavailable';$('err').textContent='Radar: '+e.message});
}

function buildTimeline(){
  S.frames=(S.source==='noaa' ? (S.noaaFrames||[]) : (S.rainFrames||[])).slice();
  $('timeline').max=Math.max(0,S.frames.length-1);
  if(S.frames.length) renderFrame(S.frames.length-1);
}

function renderFrame(i){
  if(!S.frames.length) return;
  i=Math.max(0,Math.min(i,S.frames.length-1));
  S.frame=i;
  const f=S.frames[i];
  if(S.radarLayer){S.map.removeLayer(S.radarLayer);S.radarLayer=null;}
  if(f.source==='rain'){
    const url='https://tilecache.rainviewer.com'+f.path+'/256/{z}/{x}/{y}/2/1_1.png';
    S.radarLayer=L.tileLayer(url,{opacity:.72,tileSize:256,minNativeZoom:2,maxNativeZoom:7,minZoom:2,maxZoom:12,zIndex:20,attribution:'Radar by RainViewer',updateWhenZooming:false,keepBuffer:2}).addTo(S.map);
    $('radarTag').textContent='RainViewer · observed radar';
    $('radarStatus').textContent='RainViewer observed timeline';
  }else if(f.source==='noaa'){
    noaaTimeOverlay(f.t*1000);
  }
  $('timeline').value=i;
  $('cursor').textContent=new Date(f.t*1000).toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
  $('age').textContent=(i===S.frames.length-1?'latest':'historical');
}

function noaaTimeOverlay(timeMs){
  if(!S.map || !S.map.getBounds){$('radarStatus').textContent='NOAA MRMS waiting for map';return;}
  const b=S.map.getBounds(),sw=b.getSouthWest(),ne=b.getNorthEast();
  const p1=L.CRS.EPSG3857.project(sw),p2=L.CRS.EPSG3857.project(ne);
  const sz=S.map.getSize();
  const width=Math.min(1400,Math.max(700,Math.floor(sz.x*1.35)));
  const height=Math.min(1000,Math.max(500,Math.floor(sz.y*1.35)));
  const params=new URLSearchParams({
    bbox:[p1.x,p1.y,p2.x,p2.y].join(','),bboxSR:'3857',imageSR:'3857',
    size:width+','+height,time:String(timeMs),format:'png32',transparent:'true',f:'image',
    interpolation:'RSP_BilinearInterpolation',_ : String(Date.now())
  });
  const u='https://mapservices.weather.noaa.gov/eventdriven/rest/services/radar/radar_base_reflectivity_time/ImageServer/exportImage?'+params.toString();
  S.radarLayer=L.imageOverlay(u,b,{opacity:.78,interactive:false,attribution:'NOAA MRMS'}).addTo(S.map);
  $('radarStatus').textContent='NOAA MRMS timeline';
  $('radarTag').textContent='NOAA MRMS · observed 4-hour history';
}

function noaaFallback(){
  if(!S.noaaFrames||!S.noaaFrames.length) return loadNoaaTimeline();
  S.frames=S.noaaFrames.slice();
  $('timeline').max=Math.max(0,S.frames.length-1);
  renderFrame(Math.min(S.frame,S.frames.length-1));
}

function setRadarSource(src){
  if(S.timer){clearInterval(S.timer);S.timer=null;}
  S.playing=false;$('play').textContent='▶';$('play').classList.remove('active');
  S.source=src;
  $('rainBtn').classList.toggle('active',src==='rain');
  $('noaaBtn').classList.toggle('active',src==='noaa');
  if(S.radarLayer){S.map.removeLayer(S.radarLayer);S.radarLayer=null;}
  if(src==='rain') loadRain(); else loadNoaaTimeline();
}

function httpJSON(url,done,fail){if(window.fetch){fetch(url,{cache:'no-store'}).then(function(r){if(!r.ok)throw Error('HTTP '+r.status);return r.json()}).then(done).catch(fail);return;}var x=new XMLHttpRequest();x.open('GET',url,true);x.onreadystatechange=function(){if(x.readyState===4){if(x.status>=200&&x.status<300){try{done(JSON.parse(x.responseText))}catch(e){fail(e)}}else fail(Error('HTTP '+x.status))}};x.onerror=function(){fail(Error('Network error'))};x.send(null)}
function httpText(url,done,fail){if(window.fetch){fetch(url,{cache:'no-store'}).then(function(r){if(!r.ok)throw Error('HTTP '+r.status);return r.text()}).then(done).catch(fail);return;}var x=new XMLHttpRequest();x.open('GET',url,true);x.onreadystatechange=function(){if(x.readyState===4){if(x.status>=200&&x.status<300)done(x.responseText);else fail(Error('HTTP '+x.status))}};x.onerror=function(){fail(Error('Network error'))};x.send(null)}
function openM(){return new Promise(function(resolve,reject){var u='https://api.open-meteo.com/v1/forecast?latitude='+S.lat+'&longitude='+S.lon+'&current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,relative_humidity_2m_mean,precipitation_probability_max,precipitation_sum,rain_sum,showers_sum,snowfall_sum,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation_probability,precipitation,rain,showers,snowfall,weather_code&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=auto&forecast_days=10';httpJSON(u,resolve,reject)})}
function nws(){return new Promise(function(resolve,reject){var u='https://api.weather.gov/points/'+S.lat+','+S.lon;httpJSON(u,function(pj){var h=pj.properties&&pj.properties.forecastHourly;if(!h) return reject(Error('NWS hourly endpoint unavailable'));httpJSON(h,function(hj){resolve({point:pj.properties,hours:hj.properties.periods})},reject)},reject)})}
function lookupZip(z){return new Promise(function(resolve,reject){z=(z||'').replace(/\D/g,'');if(!/^\d{5}$/.test(z))return reject(Error('Enter a valid 5-digit U.S. ZIP code'));httpJSON('https://api.zippopotam.us/us/'+z,function(j){var place=j.places&&j.places[0];if(!place)return reject(Error('ZIP code not found'));resolve({lat:+place.latitude,lon:+place.longitude,label:place['place name']+', '+place['state abbreviation']})},function(){reject(Error('ZIP code not found'))})})}
function renderHourly(d){const times=d.hourly.time;const currentMs=new Date(d.current.time).getTime();let idx=0,best=Infinity;for(let i=0;i<times.length;i++){const diff=Math.abs(new Date(times[i]).getTime()-currentMs);if(diff<best){best=diff;idx=i}}const start=Math.max(0,idx-1),end=Math.min(times.length,start+24);$('hours').innerHTML=times.slice(start,end).map((t,j)=>{const i=start+j,isCurrent=i===idx;const pp=d.hourly.precipitation_probability ? d.hourly.precipitation_probability[i] : null;const mm=d.hourly.precipitation ? d.hourly.precipitation[i] : null;let type='';if((d.hourly.snowfall ? d.hourly.snowfall[i] : 0||0)>0)type='Snow';else if((d.hourly.showers ? d.hourly.showers[i] : 0||0)>0)type='Showers';else if((d.hourly.rain ? d.hourly.rain[i] : 0||0)>0)type='Rain';return `<div class="hour${isCurrent?' active':''}"><b>${isCurrent?'Now':new Date(t).toLocaleTimeString([], {hour:'numeric'})}</b><div class="mini">${fmt(d.hourly.temperature_2m[i])}° · ${fmt(d.hourly.relative_humidity_2m[i])}%</div><div class="small">💧 ${fmt(pp)}% · ${mm==null?'--':Number(mm).toFixed(2)}"</div><div class="small">${type||'Dry'} · 💨 ${fmt(d.hourly.wind_speed_10m[i])} mph</div></div>`}).join('')}
function dval(a,i){return a&&a[i]!=null?a[i]:null}
function f2(v){return v==null?'--':Number(v).toFixed(2)}
function compass(v){if(v==null||!isFinite(v))return '--';var dirs=['N','NE','E','SE','S','SW','W','NW'];return dirs[Math.round(((Number(v)%360)+360)%360/45)%8]}
function dailyType(day,i){var snow=Number(dval(day.snowfall_sum,i)||0),showers=Number(dval(day.showers_sum,i)||0),rain=Number(dval(day.rain_sum,i)||0),total=Number(dval(day.precipitation_sum,i)||0);if(snow>0)return 'Snow';if(showers>0&&showers>=rain)return 'Showers';if(rain>0)return 'Rain';return total>0?'Precip':'Dry'}
function renderDaily(d){var day=d.daily||{},times=day.time||[];$('days').innerHTML=times.slice(0,10).map(function(t,i){var dt=new Date(t+'T12:00:00'),label=i===0?'Today':dt.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'}),high=dval(day.temperature_2m_max,i),low=dval(day.temperature_2m_min,i),hum=dval(day.relative_humidity_2m_mean,i),pop=dval(day.precipitation_probability_max,i),total=dval(day.precipitation_sum,i),rain=dval(day.rain_sum,i),showers=dval(day.showers_sum,i),snow=dval(day.snowfall_sum,i),wind=dval(day.wind_speed_10m_max,i),gust=dval(day.wind_gusts_10m_max,i),dir=dval(day.wind_direction_10m_dominant,i);return `<div class="hour daycard"><b>${label}</b><div class="mini">${wx(dval(day.weather_code,i))}</div><div class="small">High / Low: ${fmt(high)}° / ${fmt(low)}°</div><div class="small">Humidity: ${fmt(hum)}%</div><div class="small">Precip: ${fmt(pop)}% · ${f2(total)}" · ${dailyType(day,i)}</div><div class="small">Rain: ${f2(rain)}" · Showers: ${f2(showers)}"</div><div class="small">Snow: ${f2(snow)}"</div><div class="small">Wind: ${fmt(wind)} mph ${compass(dir)}</div><div class="small">Gust: ${fmt(gust)} mph</div></div>`}).join('')}
function renderOpen(d){const c=d.current;$('place').textContent=S.placeLabel||`${S.lat.toFixed(3)}, ${S.lon.toFixed(3)}`;$('temp').textContent=`${fmt(c.temperature_2m)}°F`;$('condition').textContent=wx(c.weather_code);$('stamp').textContent='Open-Meteo · '+new Date(c.time).toLocaleString();$('humidity').textContent=fmt(c.relative_humidity_2m)+'%';$('wind').textContent=fmt(c.wind_speed_10m)+' mph';$('hiLo').textContent=`${fmt(d.daily.temperature_2m_max[0])} / ${fmt(d.daily.temperature_2m_min[0])}°`;renderHourly(d);renderDaily(d)}
function renderNws(d){const x=d.hours[0];$('compare').innerHTML=`NOAA/NWS: ${x?x.temperature+'°'+x.temperatureUnit:'--'} · ${x?x.shortForecast:'—'}`}
async function refresh(){if(S.weather.has('open'))openM().then(renderOpen).catch(e=>$('err').textContent=e.message);if(S.weather.has('nws'))nws().then(renderNws).catch(e=>$('err').textContent=e.message)}
$('useZip').onclick=async()=>{try{$('err').textContent='';const z=$('zip').value.trim();const r=await lookupZip(z);S.zip=z;S.lat=r.lat;S.lon=r.lon;S.placeLabel=r.label;localStorage.zip=z;localStorage.lat=S.lat;localStorage.lon=S.lon;localStorage.placeLabel=S.placeLabel;$('lat').value=S.lat;$('lon').value=S.lon;$('place').textContent=r.label;S.map.setView([S.lat,S.lon],8);refresh();if(S.source==='rain')loadRain();else loadNoaaTimeline()}catch(e){$('err').textContent=e.message}};$('play').onclick=()=>{S.playing=!S.playing;$('play').textContent=S.playing?'❚❚':'▶';$('play').classList.toggle('active',S.playing);if(S.playing){S.timer=setInterval(()=>{const n=S.frame+1;if(n>=S.frames.length){S.playing=false;clearInterval(S.timer);$('play').textContent='▶';$('play').classList.remove('active');return}renderFrame(n)},900)}else clearInterval(S.timer)};
var timelineTimer=null;
$('timeline').oninput=e=>{var v=+e.target.value;if(timelineTimer)clearTimeout(timelineTimer);timelineTimer=setTimeout(function(){renderFrame(v)},120)};
$('timeline').onchange=e=>renderFrame(+e.target.value);
$('latest').onclick=()=>{if(S.source==='noaa'){if(!S.noaaFrames||!S.noaaFrames.length){loadNoaaTimeline();return}S.frames=S.noaaFrames.slice();$('timeline').max=S.frames.length-1;renderFrame(S.frames.length-1);}else{if(!S.rainFrames||!S.rainFrames.length){loadRain();return}S.frames=S.rainFrames.slice();$('timeline').max=S.frames.length-1;renderFrame(S.frames.length-1);}};
$('rainBtn').onclick=()=>setRadarSource('rain');
$('noaaBtn').onclick=()=>setRadarSource('noaa');
$('setBtn').onclick=()=>{$('settings').classList.toggle('show');$('setBtn').classList.toggle('active',$('settings').classList.contains('show'));$('setBtn').setAttribute('aria-pressed',$('settings').classList.contains('show'));};$('save').onclick=()=>{S.lat=+$('lat').value;S.lon=+$('lon').value;S.site=$('site').value.toUpperCase();localStorage.lat=S.lat;localStorage.lon=S.lon;localStorage.site=S.site;S.map.setView([S.lat,S.lon],8);refresh();if(S.source==='rain')loadRain();else loadNoaaTimeline()};$('hourBtn').onclick=()=>{$('hourly').scrollIntoView({behavior:'smooth'});$('hourBtn').classList.add('active');setTimeout(()=>$('hourBtn').classList.remove('active'),1200);};document.querySelectorAll('.chip[data-src]').forEach(b=>b.onclick=()=>{b.classList.toggle('active');b.classList.contains('active')?S.weather.add(b.dataset.src):S.weather.delete(b.dataset.src);refresh()});if(mapInit()){loadRain();refresh();S.map.on('moveend',function(){if(S._moveTimer)clearTimeout(S._moveTimer);S._moveTimer=setTimeout(function(){if(S.source==='noaa'&&S.frames[S.frame]&&S.frames[S.frame].source==='noaa')noaaTimeOverlay(S.frames[S.frame].t*1000)},300);});}setInterval(refresh,600000);setInterval(()=>{if(S.source==='rain')loadRain();else loadNoaaTimeline()},300000);
