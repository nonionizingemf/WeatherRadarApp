from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
GRADLE = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')


def require(cond, msg):
    if not cond:
        raise AssertionError(msg)


def main():
    require("versionCode 210" in GRADLE, "versionCode must be 210")
    require("versionName '2.0.10'" in GRADLE, "versionName must be 2.0.10")
    require('v2.0.10' in HTML and 'v2.0.8' not in HTML, "visible version must be v2.0.10")

    require('id="daily"' in HTML, "Daily section missing")
    require('id="days"' in HTML, "Daily card container missing")
    require('function renderDaily' in HTML, "renderDaily() missing")
    require('renderDaily(d)' in HTML, "renderOpen() must invoke renderDaily()")

    require('forecast_days=10' in HTML, "Open-Meteo request must ask for 10 days")
    require('forecast_days=2' not in HTML, "legacy 2-day request must be removed")
    for field in [
        'weather_code', 'temperature_2m_max', 'temperature_2m_min',
        'relative_humidity_2m_mean', 'precipitation_probability_max',
        'precipitation_sum', 'rain_sum', 'showers_sum', 'snowfall_sum',
        'wind_speed_10m_max', 'wind_gusts_10m_max', 'wind_direction_10m_dominant'
    ]:
        require(field in HTML, f"daily field missing: {field}")
    require('precipitation_unit=inch' in HTML, "Open-Meteo request must use inch precipitation units")

    for label in ['High / Low', 'Humidity', 'Precip', 'Rain', 'Showers', 'Snow', 'Wind', 'Gust']:
        require(label in HTML, f"daily card metric label missing: {label}")

    require('maxNativeZoom:7' in HTML, "RainViewer must preserve native Z7 ceiling")
    require("maxZoom:12" in HTML, "map/radar zoom ceiling must remain 12")
    require('RainViewer · observed radar' in HTML, "RainViewer observed-radar labeling changed unexpectedly")
    require('NOAA MRMS' in HTML, "NOAA MRMS fallback missing")
    require('renderHourly(d)' in HTML, "Hourly rendering must remain")

    print('Android v2.0.10 regression checks: PASS')


if __name__ == '__main__':
    main()
