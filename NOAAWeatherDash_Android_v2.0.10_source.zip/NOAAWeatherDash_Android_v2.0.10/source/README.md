# NOAA Weather Dash Android v2.0.10

## Toolchain (intentionally pinned)
- Gradle: **8.7** via the included Gradle Wrapper
- Android Gradle Plugin (AGP): **8.6.1**
- JDK: **17**
- compileSdk: **35**
- targetSdk: **35**
- minSdk: **23 (Android 6.0 / Marshmallow)**

Android Studio should use the included Gradle Wrapper. The project keeps the lightweight single-WebView architecture for legacy-device compatibility.

## Build
From the `android` directory on Windows:

```bat
gradlew.bat --version
gradlew.bat :app:assembleDebug
```

The debug APK is produced under:

`app\\build\\outputs\\apk\\debug\\app-debug.apk`

## v2.0.10 features
- Interactive Leaflet map with bundled Leaflet 1.9.4 assets.
- RainViewer observed radar with native radar zoom capped at Z7 and local interpolation through map zoom 12.
- NOAA MRMS observed-radar fallback.
- Current conditions and 24-hour Hourly cards from Open-Meteo.
- New **10-day Daily cards directly below Hourly**.
- Daily high/low, condition, mean humidity, precipitation probability/total/type, rain/showers/snow totals, max wind, dominant wind direction, and max gust.
- NOAA/NWS hourly comparison.
- U.S. ZIP lookup plus saved manual latitude/longitude settings.
- Version labels corrected to v2.0.10.

## v2.0.10 precipitation-unit change
The Open-Meteo request now asks for `precipitation_unit=inch`. Hourly and Daily precipitation values therefore render directly in inches; the older hourly mm-to-inch multiplication has been removed to avoid double conversion.

## Legacy compatibility
The application remains `minSdk 23` and does not add a new framework or runtime dependency. Leaflet remains bundled in the APK, so the map library itself does not depend on a CDN at runtime.
