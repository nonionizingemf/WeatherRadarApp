# NOAA Weather Dash Android — Features

Current baseline: **v2.0.10** (`versionCode 210`, `versionName 2.0.10`)  
Legacy support target: **Android 6.0 / API 23 and newer**  
Baseline source: preserved v2.0.9 project, incrementally updated without replacing the legacy WebView architecture.

## Implemented in v2.0.10

- Single-activity Android application using an Android `WebView`.
- Local/bundled Leaflet 1.9.4 JavaScript and CSS assets.
- Interactive Leaflet map with OpenStreetMap base tiles.
- Map zoom range 2 through 12.
- RainViewer **observed radar** timeline using current public Weather Maps metadata.
- RainViewer layer retains `maxNativeZoom: 7`; map zoom 8–12 locally enlarges Z7 radar instead of requesting unsupported higher-native-zoom radar tiles.
- NOAA MRMS observed-radar fallback with time-enabled history from the live MRMS service time extent.
- Radar timeline slider, play control, latest-frame control, and timestamp display.
- Debounced timeline/map-movement behavior for lower-end and legacy Android devices.
- Current conditions from Open-Meteo.
- 24-hour Hourly strip from Open-Meteo.
- **10-day Daily strip directly beneath Hourly.**
- Daily cards use the same horizontally scrollable card presentation as Hourly and display:
  - day/date;
  - weather condition;
  - high / low temperature;
  - mean relative humidity;
  - maximum precipitation probability;
  - total precipitation in inches;
  - dominant precipitation type / Dry indication;
  - rain total in inches;
  - showers total in inches;
  - snowfall total in inches;
  - maximum wind speed;
  - dominant wind direction as a compass point;
  - maximum wind gust.
- Hourly cards display:
  - time / current-hour indication;
  - temperature;
  - relative humidity;
  - precipitation probability;
  - precipitation amount in inches;
  - precipitation type indication derived from rain/showers/snowfall;
  - wind speed.
- Open-Meteo request now uses `forecast_days=10` and `precipitation_unit=inch`.
- Hourly precipitation no longer applies the previous mm-to-inch conversion, preventing double conversion after the API was switched to native inches.
- Current-condition panel includes temperature, condition, current humidity, wind, and current-day high/low.
- NOAA/NWS hourly comparison source through `api.weather.gov`.
- U.S. ZIP-code lookup and saved location controls.
- Manual latitude/longitude and radar-site settings.
- Persistent user settings through WebView local storage.
- Touch-oriented dark interface suitable for older phones/tablets.
- Internet permission only; no Android location permission is required by the current implementation.
- HTTPS-only network configuration (`usesCleartextTraffic=false`).
- Visible and packaged versioning corrected to **v2.0.10**.

## Preserved v2.0.9 behavior

v2.0.10 is an incremental feature release. It intentionally preserves the existing radar source separation, Leaflet bundling, map controls, ZIP/location behavior, NWS comparison, timeline handling, and API 23 minimum SDK target.

## Provider architecture status

The legacy app remains operational with no API keys. Open-Meteo is the primary weather source, NWS is the U.S. comparison source, and RainViewer / NOAA MRMS remain independent radar sources.

Additional forecast providers are **not yet enabled in v2.0.10**. The next provider work should introduce a normalized adapter boundary before adding Visual Crossing or keyed providers. Recommended provider priority and key-handling rules are documented in `specs.md` and the shared `Research/weather-provider-research.md` document.

## Known follow-up items

- NWS is still queried directly from WebView JavaScript; a future revision should explicitly identify the application to NWS rather than relying on a generic WebView/browser User-Agent.
- A normalized provider adapter model is specified but not yet implemented.
- Visual Crossing is the recommended first additional global comparison provider.
- Google Weather, OpenWeather, WeatherAPI.com, and Weatherstack should remain optional because their free-tier/key/horizon constraints differ from the no-key Open-Meteo/NWS path.
