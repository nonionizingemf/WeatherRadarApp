# NOAA Weather Dash Android v2.0.6

## Toolchain (intentionally pinned)
- Gradle: **8.7.3** via the included Gradle Wrapper
- Android Gradle Plugin (AGP): **8.6.1**
- JDK: **17**
- compileSdk: **35**
- targetSdk: **35**
- minSdk: **26 (Android 8.0)**

AGP 8.6.x is paired with Gradle 8.7, and requires JDK 17. The project uses Gradle 8.7.3 to match the existing working setup requested for this app.

## Included wrapper
The Android project includes:

- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`
- `gradle/wrapper/gradle-wrapper.jar`

Android Studio should use **Gradle Wrapper** for this project. You do not need to install a separate system Gradle distribution.

> Note: the included wrapper JAR is a self-contained bootstrap implementation that reads the pinned official Gradle 8.7.3 distribution URL and launches that distribution. It is included so the package is self-contained at the project level; it does not pretend to be an official Gradle-published JAR.

## JDK
Use Android Studio's bundled JDK 17 or another JDK 17 installation. Your previously shown Microsoft JDK 17.0.20 is appropriate.

## Build
From the `android` directory on Windows:

```bat
gradlew.bat --version
gradlew.bat :app:assembleDebug
```

The first command should identify Gradle 8.7.3. The second produces a debug APK under:

`app\\build\\outputs\\apk\\debug\\app-debug.apk`

## Android 8 / Galaxy S8+
The app remains `minSdk 26`, so Android 8.0 and newer are supported. The interface remains touch-friendly and uses the lightweight WebView design.

## Features in v2.0.6
- Interactive Leaflet map
- RainViewer observed radar timeline (current public API)
- NOAA MRMS fallback
- Current + hourly weather
- Open-Meteo and NOAA/NWS source toggles
- U.S. ZIP-code lookup and saved location
- Clear selected-button states


## v2.0.7 radar-source fix

RainViewer is treated as observed radar only. Its current public Weather Maps API provides past radar frames, not the old nowcast/composite data used by earlier builds. NOAA MRMS is handled as a separate time-enabled observed timeline using its live ImageServer time extent; the app never silently substitutes RainViewer frames for NOAA MRMS frames.
