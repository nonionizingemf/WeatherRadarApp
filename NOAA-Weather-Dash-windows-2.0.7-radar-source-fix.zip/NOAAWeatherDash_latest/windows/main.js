const {app,BrowserWindow,Menu} = require('electron');
const path=require('path');
function create(){const w=new BrowserWindow({width:1050,height:760,minWidth:520,minHeight:560,backgroundColor:'#0b1117',autoHideMenuBar:true,webPreferences:{contextIsolation:true,sandbox:true}});w.loadFile(path.join(__dirname,'web','index.html'));return w}
app.whenReady().then(()=>{create();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)create()})});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});Menu.setApplicationMenu(null);
