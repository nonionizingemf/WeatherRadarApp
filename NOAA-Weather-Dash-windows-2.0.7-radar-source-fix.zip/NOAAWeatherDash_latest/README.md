# NOAA Weather Dash 2.0 — Separate Windows and Android Apps

Two separately packaged targets share the same lightweight weather dashboard UI but have independent platform packaging:

- `windows/` — Electron app for Windows 10/11, packaged as NSIS installer and portable EXE.
- `android/` — native Android WebView app targeting Android 8.0/API 26 minimum, suitable for Galaxy S8/S8+ through current phones/tablets such as Galaxy A35 5G.

## Radar
The dashboard is designed for a true interactive radar layer in the next UI revision. The current package retains the lightweight NOAA MRMS image path as a reliable fallback. RainViewer's current public Weather Maps API exposes past radar frames; public nowcast data was discontinued in January 2026. It is treated as an observed-radar source only/fallback source. citeturn164228search0

## Weather
NOAA/NWS is the official source option. NWS documents `/points`, hourly forecast, and observation APIs; current observations can be delayed by up to about 20 minutes due to upstream QC. citeturn164228search1

Open-Meteo remains an optional fast model source in the UI.

## Build — Windows
Install Node.js 20+ and run:

    cd windows
    npm install
    npm run dist

Outputs go to `windows/dist/` as installer and portable EXE.

## Build — Android
Install Android Studio with Android SDK/Build Tools and JDK 17. Then:

    cd android
    gradlew.bat assembleDebug

The APK is produced under `android/app/build/outputs/apk/debug/`.

Minimum Android version: API 26 (Android 8.0). Target SDK is deliberately conservative for legacy WebView compatibility.

## Windows radar zoom fix (2.0.1)
The RainViewer radar tile service currently supports a maximum native tile zoom of 7. The Windows Leaflet overlay now sets `maxNativeZoom: 7` while retaining a higher map zoom limit, so Leaflet scales the highest-resolution radar tiles instead of requesting unsupported radar zoom levels.


Windows 2.0.3 adds a U.S. ZIP-code lookup in Settings. Enter a 5-digit ZIP and choose Use ZIP; the app resolves it to latitude/longitude and refreshes weather and radar.


## Windows v2.0.4 radar zoom stability

The Windows Leaflet map now clamps the interactive map to zoom 2–12 and the RainViewer overlay to its documented native tile range of zoom 2–7, using Leaflet scaling above native zoom 7. This prevents the radar service from being queried at unsupported zoom levels while preserving high map zooms. RainViewer documents a maximum tile zoom of 7.


## v2.0.7 radar-source fix

RainViewer is treated as observed radar only. Its current public Weather Maps API provides past radar frames, not the old nowcast/composite data used by earlier builds. NOAA MRMS is handled as a separate time-enabled observed timeline using its live ImageServer time extent; the app never silently substitutes RainViewer frames for NOAA MRMS frames.
