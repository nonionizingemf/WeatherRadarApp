#requires -Version 5.1

param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 8787
)

$ErrorActionPreference = 'Stop'
$BindAddress = '127.0.0.1'
$Url = "http://${BindAddress}:$Port/"
$webRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'web'))
$webRootWithSeparator = $webRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
$indexPath = Join-Path $webRoot 'index.html'
$listener = $null

function Get-ContentType {
    param([string]$Path)

    switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        '.html' { 'text/html; charset=utf-8'; break }
        '.htm'  { 'text/html; charset=utf-8'; break }
        '.js'   { 'text/javascript; charset=utf-8'; break }
        '.css'  { 'text/css; charset=utf-8'; break }
        '.json' { 'application/json; charset=utf-8'; break }
        '.png'  { 'image/png'; break }
        '.jpg'  { 'image/jpeg'; break }
        '.jpeg' { 'image/jpeg'; break }
        '.gif'  { 'image/gif'; break }
        '.svg'  { 'image/svg+xml'; break }
        '.ico'  { 'image/x-icon'; break }
        '.txt'  { 'text/plain; charset=utf-8'; break }
        default { 'application/octet-stream' }
    }
}

function Send-Response {
    param(
        [System.IO.Stream]$Stream,
        [int]$StatusCode,
        [string]$Reason,
        [string]$ContentType,
        [byte[]]$Body,
        [bool]$HeadOnly = $false
    )

    if ($null -eq $Body) {
        $Body = [byte[]]@()
    }

    $headerText = "HTTP/1.1 $StatusCode $Reason`r`n" +
                  "Content-Type: $ContentType`r`n" +
                  "Content-Length: $($Body.Length)`r`n" +
                  "Cache-Control: no-cache, no-store, must-revalidate`r`n" +
                  "Pragma: no-cache`r`n" +
                  "Connection: close`r`n" +
                  "X-Content-Type-Options: nosniff`r`n" +
                  "`r`n"

    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($headerText)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    if (-not $HeadOnly -and $Body.Length -gt 0) {
        $Stream.Write($Body, 0, $Body.Length)
    }
    $Stream.Flush()
}

function Send-TextResponse {
    param(
        [System.IO.Stream]$Stream,
        [int]$StatusCode,
        [string]$Reason,
        [string]$Message,
        [bool]$HeadOnly = $false
    )

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Message)
    Send-Response -Stream $Stream -StatusCode $StatusCode -Reason $Reason -ContentType 'text/plain; charset=utf-8' -Body $bytes -HeadOnly $HeadOnly
}

if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
    Write-Host "ERROR: Missing web\index.html at: $indexPath" -ForegroundColor Red
    exit 2
}

try {
    $ipAddress = [System.Net.IPAddress]::Parse($BindAddress)
    $listener = [System.Net.Sockets.TcpListener]::new($ipAddress, $Port)
    $listener.Start()
}
catch {
    Write-Host "ERROR: Could not listen on $Url" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "If port $Port is already in use, close the other program/server and run START_LOCALHOST.bat again." -ForegroundColor Yellow
    exit 3
}

Write-Host '============================================================'
Write-Host 'NOAA Weather Dash localhost server is RUNNING'
Write-Host "URL: $Url"
Write-Host "Serving: $webRoot"
Write-Host 'No Node.js, npm, Python, or administrator rights are required.'
Write-Host 'Keep this window open. Press Ctrl+C when finished.'
Write-Host '============================================================'

try {
    Start-Process $Url | Out-Null
}
catch {
    Write-Host "Browser did not open automatically. Open this address manually: $Url" -ForegroundColor Yellow
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $null
        $reader = $null

        try {
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)
            $requestLine = $reader.ReadLine()

            if ([string]::IsNullOrWhiteSpace($requestLine)) {
                continue
            }

            do {
                $headerLine = $reader.ReadLine()
            } while ($null -ne $headerLine -and $headerLine.Length -gt 0)

            $parts = $requestLine.Split(' ')
            if ($parts.Length -lt 3) {
                Send-TextResponse -Stream $stream -StatusCode 400 -Reason 'Bad Request' -Message 'Bad request.'
                continue
            }

            $method = $parts[0].ToUpperInvariant()
            $target = $parts[1]
            $headOnly = ($method -eq 'HEAD')

            if ($method -ne 'GET' -and $method -ne 'HEAD') {
                Send-TextResponse -Stream $stream -StatusCode 405 -Reason 'Method Not Allowed' -Message 'Only GET and HEAD are supported.' -HeadOnly $headOnly
                continue
            }

            try {
                $requestPath = $target.Split('?')[0]
                $requestPath = [System.Uri]::UnescapeDataString($requestPath)
            }
            catch {
                Send-TextResponse -Stream $stream -StatusCode 400 -Reason 'Bad Request' -Message 'Invalid request path.' -HeadOnly $headOnly
                continue
            }

            if ([string]::IsNullOrEmpty($requestPath) -or $requestPath -eq '/') {
                $requestPath = '/index.html'
            }

            $relativePath = $requestPath.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)

            try {
                $candidate = [System.IO.Path]::GetFullPath((Join-Path $webRoot $relativePath))
            }
            catch {
                Send-TextResponse -Stream $stream -StatusCode 400 -Reason 'Bad Request' -Message 'Invalid request path.' -HeadOnly $headOnly
                continue
            }

            $insideRoot = $candidate.Equals($webRoot, [System.StringComparison]::OrdinalIgnoreCase) -or
                          $candidate.StartsWith($webRootWithSeparator, [System.StringComparison]::OrdinalIgnoreCase)

            if (-not $insideRoot) {
                Send-TextResponse -Stream $stream -StatusCode 403 -Reason 'Forbidden' -Message 'Forbidden.' -HeadOnly $headOnly
                continue
            }

            if (Test-Path -LiteralPath $candidate -PathType Container) {
                $candidate = Join-Path $candidate 'index.html'
            }

            if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
                Send-TextResponse -Stream $stream -StatusCode 404 -Reason 'Not Found' -Message 'Not found.' -HeadOnly $headOnly
                continue
            }

            $body = [System.IO.File]::ReadAllBytes($candidate)
            $contentType = Get-ContentType -Path $candidate
            Send-Response -Stream $stream -StatusCode 200 -Reason 'OK' -ContentType $contentType -Body $body -HeadOnly $headOnly
        }
        catch {
            if ($null -ne $stream) {
                try {
                    Send-TextResponse -Stream $stream -StatusCode 500 -Reason 'Internal Server Error' -Message 'Server error.'
                }
                catch {
                }
            }
            Write-Host "Request error: $($_.Exception.Message)" -ForegroundColor Yellow
        }
        finally {
            if ($null -ne $reader) { $reader.Dispose() }
            if ($null -ne $stream) { $stream.Dispose() }
            $client.Close()
        }
    }
}
finally {
    if ($null -ne $listener) {
        $listener.Stop()
    }
}
