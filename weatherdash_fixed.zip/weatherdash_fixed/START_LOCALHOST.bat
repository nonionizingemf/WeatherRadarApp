@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NOAA Weather Dash - Localhost

set "SERVER_PS=%~dp0localhost_server.ps1"
set "WEB_INDEX=%~dp0web\index.html"
set "LOCAL_URL=http://127.0.0.1:8787/"

echo ============================================================
echo NOAA Weather Dash - Localhost Launcher
echo ============================================================
echo Project: %~dp0
echo URL:     %LOCAL_URL%
echo.

echo [1/3] Checking project files...
if not exist "%WEB_INDEX%" (
    echo FAIL: Missing "%WEB_INDEX%"
    echo Extract the complete ZIP before running this launcher.
    set "FINAL_RC=2"
    goto :FAIL
)
if not exist "%SERVER_PS%" (
    echo FAIL: Missing "%SERVER_PS%"
    set "FINAL_RC=3"
    goto :FAIL
)
echo PASS: Project files found.
echo.

echo [2/3] Checking Windows PowerShell...
where powershell.exe >nul 2>&1
set "PS_CHECK_RC=%ERRORLEVEL%"
if not "%PS_CHECK_RC%"=="0" (
    echo FAIL: powershell.exe was not found on PATH.
    echo This launcher requires the Windows PowerShell included with Windows 10.
    set "FINAL_RC=4"
    goto :FAIL
)
echo PASS: Windows PowerShell found.
echo.

echo [3/3] Starting localhost server...
echo The browser should open automatically at:
echo   %LOCAL_URL%
echo.
echo Keep this window open while using Weather Dash.
echo Close this window or press Ctrl+C when finished.
echo ============================================================
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SERVER_PS%" -Port 8787
set "FINAL_RC=%ERRORLEVEL%"

if "%FINAL_RC%"=="0" goto :END

echo.
echo FAIL: Localhost server exited with ERRORLEVEL %FINAL_RC%.
goto :FAIL_NO_HEADER

:FAIL
echo.
:FAIL_NO_HEADER
echo ============================================================
echo Weather Dash localhost did not start successfully.
echo ERRORLEVEL = %FINAL_RC%
echo ============================================================
pause
exit /b %FINAL_RC%

:END
echo.
echo Localhost server stopped.
exit /b 0
