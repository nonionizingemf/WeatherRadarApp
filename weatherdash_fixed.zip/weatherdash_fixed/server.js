const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 8787);
const WEB_ROOT = path.join(__dirname, 'web');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function resolveWebPath(requestUrl) {
  const pathname = decodeURIComponent(new URL(requestUrl, `http://${HOST}:${PORT}`).pathname);
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const candidate = path.resolve(WEB_ROOT, relative);
  if (candidate !== WEB_ROOT && !candidate.startsWith(WEB_ROOT + path.sep)) return null;
  return candidate;
}

function createServer() {
  return http.createServer((req, res) => {
    const file = resolveWebPath(req.url || '/');
    if (!file) {
      res.writeHead(403, {'Content-Type':'text/plain; charset=utf-8'});
      return res.end('Forbidden');
    }
    fs.stat(file, (statErr, st) => {
      const target = !statErr && st.isDirectory() ? path.join(file, 'index.html') : file;
      fs.readFile(target, (err, data) => {
        if (err) {
          res.writeHead(err.code === 'ENOENT' ? 404 : 500, {'Content-Type':'text/plain; charset=utf-8'});
          return res.end(err.code === 'ENOENT' ? 'Not found' : 'Server error');
        }
        res.writeHead(200, {
          'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream',
          'Cache-Control': 'no-cache'
        });
        res.end(data);
      });
    });
  });
}

function openDefaultBrowser(url) {
  let command, args;
  if (process.platform === 'win32') {
    command = 'cmd'; args = ['/c', 'start', '', url];
  } else if (process.platform === 'darwin') {
    command = 'open'; args = [url];
  } else {
    command = 'xdg-open'; args = [url];
  }
  const child = spawn(command, args, { detached: true, stdio: 'ignore' });
  child.on('error', () => {});
  child.unref();
}

if (require.main === module) {
  const server = createServer();
  server.listen(PORT, HOST, () => {
    const url = `http://${HOST}:${PORT}/`;
    console.log(`Weather Dash browser server: ${url}`);
    console.log('Press Ctrl+C to stop.');
    openDefaultBrowser(url);
  });
}

module.exports = { createServer, resolveWebPath };
