const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('uses the canonical OpenStreetMap tile endpoint without legacy subdomains', () => {
  assert.match(html, /https:\/\/tile\.openstreetmap\.org\/\{z\}\/\{x\}\/\{y\}\.png/);
  assert.doesNotMatch(html, /\{s\}\.tile\.openstreetmap\.org/);
});

test('reports basemap tile failures instead of failing silently', () => {
  assert.match(html, /tileerror/);
  assert.match(html, /basemap/i);
});

test('provides an HTTP browser launcher so Chrome Edge and Firefox do not need file URLs', () => {
  assert.equal(pkg.scripts.browser, 'node server.js');
  assert.equal(fs.existsSync(path.join(root, 'server.js')), true);
});

test('Electron identifies the application with a stable app-specific user agent', () => {
  assert.match(main, /setUserAgent\(/);
  assert.match(main, /WeatherDash\/2\.0/);
});
