const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const batPath = path.join(root, 'START_LOCALHOST.bat');
const psPath = path.join(root, 'localhost_server.ps1');

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

test('ships a no-install Windows localhost launcher anchored to its own folder', () => {
  assert.equal(fs.existsSync(batPath), true, 'START_LOCALHOST.bat is missing');
  const bat = read(batPath);
  assert.match(bat, /%~dp0/);
  assert.match(bat, /powershell\.exe/i);
  assert.match(bat, /web\\index\.html/i);
  assert.match(bat, /ERRORLEVEL/i);
});

test('PowerShell localhost server uses loopback TcpListener and serves only web directory', () => {
  assert.equal(fs.existsSync(psPath), true, 'localhost_server.ps1 is missing');
  const ps = read(psPath);
  assert.match(ps, /TcpListener/);
  assert.match(ps, /127\.0\.0\.1/);
  assert.match(ps, /8787/);
  assert.match(ps, /#requires -Version 5\.1/i);
  assert.match(ps, /TcpListener\]::new/);
  assert.match(ps, /StreamReader\]::new/);
  assert.match(ps, /Join-Path \$PSScriptRoot ['"]web['"]/);
  assert.doesNotMatch(ps, /HttpListener/);
});

test('PowerShell localhost server launches the default browser and rejects traversal', () => {
  const ps = read(psPath);
  assert.match(ps, /Start-Process/);
  assert.match(ps, /StartsWith\(\$webRoot/i);
  assert.match(ps, /403/);
});
