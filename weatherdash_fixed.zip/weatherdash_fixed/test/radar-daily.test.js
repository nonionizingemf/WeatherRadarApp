const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');

test('RainViewer is capped at native zoom 7 while allowing Leaflet to upscale at higher map zooms', () => {
  assert.match(html, /maxNativeZoom\s*:\s*7/);
  assert.match(html, /maxZoom\s*:\s*12/);
});

test('renders a Daily forecast section directly below Hourly', () => {
  const hourlyPos = html.indexOf('<b>Hourly</b>');
  const dailyPos = html.indexOf('<b>Daily</b>');
  assert.ok(hourlyPos >= 0, 'Hourly heading missing');
  assert.ok(dailyPos > hourlyPos, 'Daily heading must appear after Hourly');
  assert.match(html, /id=["']days["']/);
});

test('requests seven-day Open-Meteo daily forecast fields used by Daily cards', () => {
  assert.match(html, /forecast_days=7/);
  assert.match(html, /daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,wind_speed_10m_max/);
});

test('Daily renderer includes condition, high-low, precipitation and wind', () => {
  assert.match(html, /function\s+renderDaily\s*\(/);
  assert.match(html, /precipitation_probability_max/);
  assert.match(html, /wind_speed_10m_max/);
  assert.match(html, /temperature_2m_max/);
  assert.match(html, /temperature_2m_min/);
});
