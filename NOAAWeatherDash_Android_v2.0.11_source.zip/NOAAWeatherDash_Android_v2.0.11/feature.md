# NOAA Weather Dash Android — Features

Current baseline: **v2.0.11** (`versionCode 211`, `versionName 2.0.11`)  
Legacy support target: **Android 6.0 / API 23 and newer**  
Source lineage: preserved v2.0.10 baseline, incrementally extended without replacing the single-WebView architecture.

## Implemented in v2.0.11

- Everything retained from v2.0.10, including:
  - bundled Leaflet 1.9.4;
  - OpenStreetMap base map;
  - RainViewer observed-radar timeline with `maxNativeZoom: 7` and local enlargement through map zoom 12;
  - NOAA MRMS observed-radar fallback;
  - Open-Meteo current conditions;
  - 24-hour Hourly strip;
  - Open-Meteo 10-day Daily strip;
  - NOAA/NWS hourly comparison;
  - ZIP/latitude/longitude persistence and legacy Android WebView shell.

### Visual Crossing 15-day forecast

A new **Visual Crossing 15-day Daily** strip appears directly below the Open-Meteo 10-day strip. It uses the Timeline API and requests daily-only data.

Each Visual Crossing card shows:

- day/date;
- condition text;
- high / low temperature;
- mean temperature;
- mean humidity;
- precipitation probability;
- precipitation amount;
- precipitation type(s);
- snowfall;
- maximum wind speed;
- wind direction as a compass point;
- wind gust.

Anonymous/no-key access is the default. Settings also contains an optional Visual Crossing personal-key field for users who want their own quota/account allowance. The key is stored only in WebView local storage; no shared key is shipped in the APK source.

### Past 7 Days history

A new **Past 7 Days** strip appears below the two forecast rows. It intentionally covers the **seven completed calendar days ending yesterday**, avoiding partial-today precipitation totals.

Primary history values come from Visual Crossing daily history and include:

- condition;
- high / low;
- mean temperature;
- humidity;
- precipitation amount/type;
- snowfall;
- wind speed/direction;
- gust.

Each history card also displays an **Open-Meteo reanalysis** comparison for high, low, and total precipitation when available. The reanalysis comparison is explicitly labeled and is not presented as a direct weather-station observation.

History and forecast failures are isolated: Visual Crossing can fail without breaking Open-Meteo, NWS, RainViewer, or NOAA MRMS.

### Visual Crossing precipitation map layer

Radar/source controls now provide three map choices:

- **RainViewer observed** — animated observed-radar history;
- **NOAA MRMS fallback** — direct NOAA time-enabled MRMS imagery;
- **VC Precip** — Visual Crossing `precipcomposite` XYZ tiles showing precipitation intensity/type using the latest composite available.

The VC layer is labeled as a precipitation composite rather than an independent U.S. radar source. It uses required visible attribution: `Weather data © Visual Crossing`.

VC map tiles are only loaded while the VC source is selected. The layer is refreshed on a five-minute app cadence, with a ten-minute cache-busting bucket to avoid needless per-request URL churn.

## Request cadence

- Open-Meteo current/hourly/10-day: existing 10-minute refresh.
- Visual Crossing 15-day forecast: no more often than every 30 minutes unless location/settings are explicitly changed.
- Visual Crossing + Open-Meteo seven-day history: once per 24 hours unless location/settings are explicitly changed.
- RainViewer/NOAA/VC map source: existing five-minute source refresh cadence; only the currently selected map layer is refreshed.

## Legacy compatibility notes

- `minSdk 23` remains unchanged.
- No new Android framework or third-party runtime dependency was added.
- Bundled Leaflet remains local to the APK.
- Existing XHR fallback remains available when `fetch` is unavailable.
- Production JavaScript avoids `String.prototype.padStart()` in the new date-range code to reduce reliance on newer WebView JavaScript features.

## Known release limitation

Source/runtime tests pass in the development sandbox, but the Android APK could not be built there because the Gradle wrapper cannot resolve `services.gradle.org`. A normal networked Android build machine must still run the release build/install test.
