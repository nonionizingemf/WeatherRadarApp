# NOAA Weather Dash Android — Technical Specifications

Current baseline: **v2.0.11**  
Source lineage: **v2.0.10 preserved and incrementally extended**  
Legacy support goal: **Android 6.0 / API 23+**

## 1. Build and platform baseline

- Application ID: `com.noaaweatherdash.android`
- Namespace: `com.noaaweatherdash`
- Version: code `211`, name `2.0.11`
- `minSdk 23`
- `targetSdk 35`
- `compileSdk 35`
- Android Gradle Plugin: `8.6.1`
- Gradle wrapper target: `8.7`
- JDK: `17`
- Main activity: `com.noaaweatherdash.MainActivity`
- UI runtime: Android WebView loading `file:///android_asset/index.html`
- Leaflet 1.9.4 bundled in assets
- `INTERNET` permission only
- cleartext HTTP disabled

## 2. Provider roles

### Open-Meteo

Primary current/hourly/10-day forecast source.

Existing forecast contract remains:

- `forecast_days=10`
- Fahrenheit temperature
- mph wind
- inch precipitation
- current, hourly, and daily fields used by v2.0.10

Open-Meteo Historical Weather `/v1/archive` supplies a secondary reanalysis comparison for the seven completed historical days. The v2.0.11 request uses supported daily aggregates:

- `weather_code`
- `temperature_2m_max`
- `temperature_2m_min`
- `precipitation_sum`
- `rain_sum`
- `snowfall_sum`
- `wind_speed_10m_max`
- `wind_gusts_10m_max`
- `wind_direction_10m_dominant`

The UI currently compares Open-Meteo historical high/low and total precipitation against the Visual Crossing history row.

### NOAA/NWS

Retained as the U.S. hourly comparison source. It remains independent of all Visual Crossing functions.

### Visual Crossing Timeline API

v2.0.11 uses the Timeline API anonymously by default. An optional per-user key may be stored in local WebView storage and appended as `key=` when present.

Forecast endpoint form:

```text
https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/{lat},{lon}
  ?unitGroup=us
  &include=days
  &elements=datetime,tempmax,tempmin,temp,humidity,precip,precipprob,preciptype,snow,windspeed,windgust,winddir,conditions
  &contentType=json
```

With no dates, the Timeline API provides the standard forward forecast; the UI renders at most 15 day records.

Historical endpoint form:

```text
https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/{lat},{lon}/{start}/{end}
  ?unitGroup=us
  &include=days
  &elements=datetime,tempmax,tempmin,temp,humidity,precip,preciptype,snow,windspeed,windgust,winddir,conditions
  &contentType=json
```

`start` and `end` are the seven completed calendar dates ending yesterday.

## 3. History semantics

The history section must not imply that all providers represent the same measurement process.

- Visual Crossing values are labeled **Visual Crossing history**.
- Open-Meteo values are labeled **Open-Meteo reanalysis**.
- The app does not average or merge the two into a synthetic “truth” value.
- Missing values remain `--`; missing provider data must never be converted to zero.
- Today is intentionally excluded to prevent partial daily precipitation totals from being compared with complete prior days.

The minimum comparison objective is prior daily temperature and precipitation verification.

## 4. Visual Crossing precipitation map

Tile template:

```text
https://maps.visualcrossing.com/VisualCrossingWebServices/rest/api/v1/map/tile/precipcomposite/{z}/{x}/{y}.webp?time=latest
```

If a personal key is configured, append `&key=...`.

Leaflet settings:

- tile size: 256
- app map zoom: 2–12
- layer max zoom: 12
- opacity: approximately 0.78
- attribution: `Weather data © Visual Crossing`
- map-layer identifier shown to the user: **VC Precip** / **Visual Crossing precipitation composite**

The layer is not described as a fully independent U.S. radar source because Visual Crossing's U.S. precipitation composite can use NOAA NEXRAD/MRMS among its underlying sources.

## 5. Radar-source state contract

`S.source` supports:

```text
rain  RainViewer observed timeline
noaa  NOAA MRMS time-enabled imagery
vc    Visual Crossing latest precipitation composite
```

Only one weather overlay is active at a time.

When `vc` is selected:

- animation/timeline playback is stopped;
- the radar timeline collapses to one “Latest” state;
- only VC precipitation tiles are requested;
- `Latest` recreates the VC layer;
- map move does not invoke the NOAA image-overlay refresh path.

## 6. Refresh/caching policy

- Open-Meteo/NWS regular weather refresh: 10 minutes.
- Visual Crossing 15-day forecast: 30-minute minimum refresh interval.
- Seven-day history pair: 24-hour minimum refresh interval.
- Explicit ZIP/coordinate/settings changes force both extended requests immediately.
- Selected radar source refresh: five minutes.
- VC map URL uses a ten-minute bucket parameter so browser/WebView cache can remain effective inside each bucket.

## 7. Error isolation

The following failures must remain independent:

- Visual Crossing forecast failure must not remove Open-Meteo 10-day cards.
- Visual Crossing history failure must still allow Open-Meteo reanalysis history values to render.
- Open-Meteo archive failure must still allow Visual Crossing history to render.
- VC map tile failure must not break RainViewer or NOAA MRMS selection.
- Optional VC-key failure must not prevent users from clearing the key and returning to anonymous access.

## 8. Optional-key handling

No shared Visual Crossing credential is embedded.

The optional key:

- is typed in Settings;
- is stored as `localStorage.vcKey`;
- is URL-encoded when appended;
- is intentionally treated as a user-supplied local credential, not a protected application secret.

Because WebView/localStorage and APK/client traffic are inspectable, this mechanism is appropriate only for a user's own key, not for distributing a private shared service credential.

## 9. Legacy WebView constraints

- Maintain API 23 minimum Android support.
- Keep bundled Leaflet.
- Preserve XHR fallback.
- Avoid unnecessary new JS/runtime dependencies.
- New production date formatting does not use `String.prototype.padStart()`.
- Keep touch targets and horizontal card scrolling usable on small displays.

## 10. v2.0.11 verification gates

Completed source/runtime verification:

- `python3 test/test_v211.py`
- `node test/render_daily_runtime.js`
- `node test/render_v211_runtime.js`
- `node test/render_vc_map_runtime.js`
- extracted inline JavaScript passes `node --check`

The runtime tests verify:

- 10 Open-Meteo daily cards remain functional;
- exactly 15 Visual Crossing forecast cards render from a 15-day sample;
- exactly seven history cards render from matched dates;
- historical precipitation comparison is retained;
- anonymous VC map URL contains no key;
- configured VC key is URL-encoded;
- Visual Crossing attribution and precip-composite tile URL are correct.

Android build remains a release gate because the sandbox cannot resolve `services.gradle.org` to download the Gradle distribution.

Required release validation on a normal development machine:

1. `gradlew.bat :app:assembleDebug`
2. install/start on a representative API-23-era or other legacy Android device;
3. verify anonymous Visual Crossing Timeline responses in WebView;
4. verify VC WebP map tiles render;
5. verify optional-key mode;
6. verify history date range ends yesterday and renders seven cards;
7. verify provider failures remain isolated;
8. confirm RainViewer still never requests native radar zoom above Z7.

## 11. Provider references

Research/verification date: **2026-11-19**.

- Visual Crossing no-key guide: https://www.visualcrossing.com/resources/documentation/weather-api/free-weather-api-no-key/
- Visual Crossing Timeline API: https://www.visualcrossing.com/resources/documentation/weather-api/timeline-weather-api/
- Visual Crossing Weather Maps API: https://www.visualcrossing.com/resources/documentation/weather-api/weather-maps-api/
- Open-Meteo Historical Weather API: https://open-meteo.com/en/docs/historical-weather-api
- Open-Meteo Forecast API: https://open-meteo.com/en/docs
- NOAA/NWS API: https://www.weather.gov/documentation/services-web-api
