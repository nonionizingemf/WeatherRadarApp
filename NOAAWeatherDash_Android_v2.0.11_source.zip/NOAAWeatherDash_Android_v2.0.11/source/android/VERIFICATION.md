# v2.0.11 verification

Completed source/runtime checks:

1. `python3 test/test_v211.py` — PASS
2. `node test/render_daily_runtime.js` — PASS
3. `node test/render_v211_runtime.js` — PASS
4. `node test/render_vc_map_runtime.js` — PASS
5. Extracted inline JavaScript checked with `node --check` — PASS

Verified behaviors include:

- v2.0.11 package/visible versioning;
- Open-Meteo 10-day forecast preserved;
- RainViewer native zoom ceiling Z7 preserved;
- 15 Visual Crossing forecast cards;
- seven completed historical-day cards;
- Open-Meteo reanalysis comparison label/data;
- Visual Crossing anonymous and optional-key URL construction;
- Visual Crossing precipitation-composite tile URL and attribution;
- no `String.prototype.padStart()` dependency in production HTML/JS.

Build-environment limitation:

`./gradlew :app:assembleDebug` cannot start the Android build in the sandbox because the Gradle wrapper cannot resolve `services.gradle.org` (`UnknownHostException`). This occurs while trying to download the Gradle distribution, before an Android compile result is produced.

A final APK build/install test is still required on a networked Android development machine with JDK 17 / Android SDK 35.
