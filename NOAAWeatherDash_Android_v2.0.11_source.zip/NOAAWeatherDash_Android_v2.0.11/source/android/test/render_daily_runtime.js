const fs=require('fs');
const src=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const target={innerHTML:''};
function $(id){ if(id==='days') return target; return {}; }
function fmt(v){return v==null?'--':Math.round(v)}
function wx(code){return ({0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',73:'Snow',75:'Heavy snow',80:'Showers',81:'Showers',82:'Heavy showers',95:'Thunderstorm'})[code]||'Conditions'}
const start=src.indexOf('function dval(');
const end=src.indexOf('function renderOpen(', start);
if(start<0||end<0) throw new Error('daily function block not found');
eval(src.slice(start,end));
const daily={time:[],weather_code:[],temperature_2m_max:[],temperature_2m_min:[],relative_humidity_2m_mean:[],precipitation_probability_max:[],precipitation_sum:[],rain_sum:[],showers_sum:[],snowfall_sum:[],wind_speed_10m_max:[],wind_gusts_10m_max:[],wind_direction_10m_dominant:[]};
for(let i=0;i<10;i++){
  daily.time.push(`2026-11-${String(19+i).padStart(2,'0')}`);
  daily.weather_code.push(i===0?61:0);
  daily.temperature_2m_max.push(50+i); daily.temperature_2m_min.push(30+i);
  daily.relative_humidity_2m_mean.push(65); daily.precipitation_probability_max.push(i===0?80:10);
  daily.precipitation_sum.push(i===0?0.25:0); daily.rain_sum.push(i===0?0.25:0); daily.showers_sum.push(0); daily.snowfall_sum.push(0);
  daily.wind_speed_10m_max.push(12); daily.wind_gusts_10m_max.push(20); daily.wind_direction_10m_dominant.push(270);
}
renderDaily({daily});
const count=(target.innerHTML.match(/class="hour daycard"/g)||[]).length;
if(count!==10) throw new Error(`expected 10 daily cards, got ${count}`);
for(const token of ['High / Low:','Humidity:','Precip:','Rain:','Showers:','Snow:','Wind:','Gust:']) if(!target.innerHTML.includes(token)) throw new Error(`missing ${token}`);
if(!target.innerHTML.includes('0.25"')) throw new Error('native inch precipitation not rendered');
if(!target.innerHTML.includes('W</div>')) throw new Error('wind direction cardinal conversion failed');
console.log('Daily renderer runtime check: PASS');
