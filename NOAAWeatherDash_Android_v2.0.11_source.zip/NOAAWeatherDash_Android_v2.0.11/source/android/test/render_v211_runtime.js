const fs=require('fs');
const src=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const els={vcDays:{innerHTML:''},vcDailyStatus:{textContent:''},historyDays:{innerHTML:''},historyStatus:{textContent:''}};
function $(id){return els[id]||{innerHTML:'',textContent:''};}
function fmt(v){return v==null?'--':Math.round(v)}
function wx(code){return ({0:'Clear',61:'Light rain',71:'Light snow'})[code]||'Conditions'}
const S={vcKey:'',vcHistory:null,omHistory:null,vcForecastFetched:0,historyFetched:0};
const start=src.indexOf('function dval(');
const end=src.indexOf('function renderOpen(',start);
if(start<0||end<0) throw new Error('v2.0.11 render block not found');
eval(src.slice(start,end));
const fcst={days:[]};
for(let i=0;i<15;i++)fcst.days.push({datetime:`2026-11-${String(i+19).padStart(2,'0')}`,tempmax:50+i,tempmin:30+i,temp:40+i,humidity:60,precip:i===0?0.25:0,precipprob:i===0?80:10,preciptype:i===0?['rain']:null,snow:0,windspeed:12,windgust:20,winddir:270,conditions:i===0?'Rain':'Clear'});
renderVcDaily(fcst);
let n=(els.vcDays.innerHTML.match(/class="hour daycard"/g)||[]).length;
if(n!==15) throw new Error(`expected 15 VC cards, got ${n}`);
for(const token of ['High / Low:','Mean:','Humidity:','Precip:','Snow:','Wind:','Gust:']) if(!els.vcDays.innerHTML.includes(token)) throw new Error(`VC card missing ${token}`);
if(!els.vcDays.innerHTML.includes('rain')) throw new Error('VC precip type missing');
if(!els.vcDailyStatus.textContent.includes('anonymous')) throw new Error('anonymous VC status missing');

S.vcHistory={days:[]};
const om={time:[],temperature_2m_max:[],temperature_2m_min:[],temperature_2m_mean:[],precipitation_sum:[],weather_code:[]};
for(let i=0;i<7;i++){
  const d=`2026-11-${String(i+11).padStart(2,'0')}`;
  S.vcHistory.days.push({datetime:d,tempmax:45+i,tempmin:28+i,temp:36+i,humidity:70,precip:i===2?0.31:0,preciptype:i===2?['rain']:null,snow:0,windspeed:10,windgust:18,winddir:180,conditions:i===2?'Rain':'Clear'});
  om.time.push(d);om.temperature_2m_max.push(44+i);om.temperature_2m_min.push(27+i);om.temperature_2m_mean.push(35+i);om.precipitation_sum.push(i===2?0.28:0);om.weather_code.push(i===2?61:0);
}
S.omHistory={daily:om};
renderHistory();
n=(els.historyDays.innerHTML.match(/class="hour daycard"/g)||[]).length;
if(n!==7) throw new Error(`expected 7 history cards, got ${n}`);
if(!els.historyDays.innerHTML.includes('VC precip: 0.31"')) throw new Error('VC historical precip missing');
if(!els.historyDays.innerHTML.includes('Open-Meteo reanalysis:')) throw new Error('OM reanalysis comparison missing');
if(!els.historyDays.innerHTML.includes('precip 0.28"')) throw new Error('OM precip comparison missing');
console.log('v2.0.11 forecast/history runtime check: PASS');
