# NOAA Weather Dash Android v2.0.11

## Toolchain
- Gradle 8.7 via wrapper
- Android Gradle Plugin 8.6.1
- JDK 17
- compileSdk / targetSdk 35
- minSdk 23 (Android 6.0)

## Build
From `android` on Windows:

```bat
gradlew.bat --version
gradlew.bat :app:assembleDebug
```

Debug APK:

`app\build\outputs\apk\debug\app-debug.apk`

## v2.0.11 additions
- Visual Crossing 15-day Daily forecast beneath Open-Meteo 10-day Daily.
- Past seven completed days of Visual Crossing history, with Open-Meteo reanalysis high/low and precipitation comparison.
- Third selectable weather-map overlay: Visual Crossing precipitation composite (`VC Precip`).
- Anonymous Visual Crossing access by default; optional user-supplied key in Settings.
- Extended-source refresh throttling: 30 minutes for VC forecast, 24 hours for history.
- All v2.0.10 Hourly, Open-Meteo, NWS, RainViewer, NOAA MRMS and ZIP/location behavior retained.

## Legacy compatibility
No new Android library/framework dependency was added. Leaflet remains bundled, XHR fallback remains present, and new production date code avoids `String.prototype.padStart()`.
